﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Newtonsoft.Json;
using CST_350_Minesweeper_Website.Services.Business;
using System.Data.SqlClient;  // Ensure this using directive is added to handle SQL operations
using CST_350_Minesweeper_Website.Models;
using System;

public class GameController : Controller
{
    private static bool gameStarted;
    private static bool gameIsOver;
    private static int cellsLeft;
    private static int bombCount;
    private string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=MinesweeperDB;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;MultiSubnetFailover=False";


    // ------------------------------------------------- INDEX VIEW -------------------------------------------------- //
    public IActionResult Index()
    {
        if (HttpContext.Session.GetString("User") == null)
        {
            return RedirectToAction("Index", "Login");
        }
        return View();
    }
    // ---------------------------------------------- END OF INDEX VIEW ---------------------------------------------- //

    // ------------------------------------------------- BOARD VIEW -------------------------------------------------- //
    public IActionResult Board()
    {
        return View("Board", GetBoard());
    }
    // ---------------------------------------------- END OF BOARD VIEW ---------------------------------------------- //

    // ------------------------------------------------ RESUME ACTION ------------------------------------------------ //
    public IActionResult Resume()
    {
        if (HttpContext.Session.GetString("Board") != null)
        {
            return RedirectToAction("Index", "Theme");
        }
        return RedirectToAction("Board", "Game");
    }
    // --------------------------------------------- END OF RESUME ACTION -------------------------------------------- //

    // ------------------------------------------------- START ACTION ------------------------------------------------ //
    [HttpPost]
    public IActionResult Initialize(string boardSize, string difficulty)
    {
        int boardSizeInt = 0;
        switch (boardSize)
        {
            case "small": boardSizeInt = 10; break;
            case "medium": boardSizeInt = 15; break;
            case "large": boardSizeInt = 20; break;
        }

        int difficultyInt = 0;
        switch (difficulty)
        {
            case "easy": difficultyInt = 10; break;
            case "medium": difficultyInt = 15; break;
            case "hard": difficultyInt = 20; break;
        }

        Board board = new Board(boardSizeInt, difficultyInt);
        gameStarted = false;
        gameIsOver = false;
        HttpContext.Session.SetString("GameStarted", "false");
        SaveBoard(board);
        return RedirectToAction("Board");
    }
    // ---------------------------------------------- END OF START ACTION -------------------------------------------- //

    // ------------------------------------------------- RESTART ACTION ---------------------------------------------- //
    public IActionResult Start()
    {
        HttpContext.Session.Remove("Board");
        HttpContext.Session.SetString("GameStarted", "false");
        return RedirectToAction("Index", "Theme");
    }
    // ---------------------------------------------- END OF RESTART ACTION ------------------------------------------ //

    public IActionResult Configure()
    {
        return View();
    }

    // --------------------------------------------------- WIN VIEW -------------------------------------------------- //
    public IActionResult Win()
    {
        int score = CalculateScore();
        HttpContext.Session.Remove("Board");
        return View(score);
    }
    // ------------------------------------------------ END OF WIN VIEW ---------------------------------------------- //

    public IActionResult Loss()
    {
        return View();
    }
    // ------------------------------------------------ END OF LOSS VIEW ---------------------------------------------- //

    // -------------------------------------------- CALCULATE SCORE METHOD ------------------------------------------- //
    private int CalculateScore()
    {
        Board board = GetBoard();
        TimeSpan elapsedTime = DateTime.Now - DateTime.Parse(HttpContext.Session.GetString("StartTime"));
        int baseScore = 10000;
        double sizeMulti = (double)board.Size / 10;
        double diffMulti = (double)board.Difficulty / 10;
        double score = (baseScore * sizeMulti * diffMulti) / (elapsedTime.TotalSeconds + 1);
        return (int)score;
    }
    // ----------------------------------------- END OF CALCULATE SCORE METHOD --------------------------------------- //

    // ---------------------------------------------- REVEAL CELL ACTION --------------------------------------------- //
    [HttpPost]
    public IActionResult RevealCell(string cellLocation)
    {
        var parts = cellLocation.Split(',');
        int row = Convert.ToInt32(parts[0]);
        int col = Convert.ToInt32(parts[1]);

        Board board = GetBoard();

        if (!gameStarted)
        {
            board.GenerateBombs(row, col);
            gameStarted = true;
            HttpContext.Session.SetString("GameStarted", "true");
            HttpContext.Session.SetString("StartTime", DateTime.Now.ToString());
        }

        Cell cell = board.Grid[row, col];
        (gameIsOver, cellsLeft, bombCount) = board.UpdateBoard(row, col, false, false);
        SaveBoard(board);

        if (gameIsOver)
        {
            HttpContext.Session.SetString("GameStarted", "false");
            return cellsLeft == 0 ? RedirectToAction("Win") : RedirectToAction("Loss");
        }
        return RedirectToAction("Board");
    }
    // -------------------------------------------- END OF REVEAL CELL ACTION ------------------------------------------ //

    // ------------------------------------------------ GET BOARD METHOD ----------------------------------------------- //
    private Board GetBoard()
    {
        var boardJson = HttpContext.Session.GetString("Board");
        return string.IsNullOrEmpty(boardJson) ? null : JsonConvert.DeserializeObject<Board>(boardJson);
    }
    // --------------------------------------------- END OF GET BOARD METHOD -------------------------------------------- //

    // ------------------------------------------------ SAVE BOARD METHOD ----------------------------------------------- //
    private void SaveBoard(Board board)
    {
        var boardJson = JsonConvert.SerializeObject(board);
        HttpContext.Session.SetString("Board", boardJson);
    }
    // --------------------------------------------- END OF SAVE BOARD METHOD ------------------------------------------- //

    // ---------------------------------------------- SAVE ACTION ----------------------------------------------------- //
    // Saves the current game state to the database.
    [HttpPost]
    public ActionResult Save()
    {
        var gameBoard = GetBoard(); // Fetch the current state of the game
        if (gameBoard != null)
        {
            var gameData = JsonConvert.SerializeObject(gameBoard); // Serialize the state
            SaveGameData(gameData); // Insert into the database
            return Json(new { success = true });
        }
        return Json(new { success = false });
    }

    // Inserts the serialized game data into the database.
    private void SaveGameData(string gameData)
    {
        // Create a new database connection using the connection string.
        using (var connection = new SqlConnection(connectionString))
        {
            // Open the connection to the database.
            connection.Open();

            // SQL query to insert a new game record into the Games table.
            var query = "INSERT INTO Games (UserId, DateSaved, GameData) VALUES (@UserId, @DateSaved, @GameData)";

            // Create a command object to execute the query, using the open connection.
            using (var command = new SqlCommand(query, connection))
            {
                // Retrieve the user ID from session or default to 0 if not found.
                command.Parameters.AddWithValue("@UserId", HttpContext.Session.GetInt32("UserId") ?? 0);

                // Use the current date and time as the saved date.
                command.Parameters.AddWithValue("@DateSaved", DateTime.Now);

                // Add the game data, which is a serialized JSON string of the game state.
                command.Parameters.AddWithValue("@GameData", gameData);

                // Execute the command which inserts the record into the database.
                command.ExecuteNonQuery();
            }
        }
    }


    ///-----------------------------------------------SHOW GAME-----------------------------------------------------------------------///
    public IActionResult ShowSavedGames()
    {
        try
        {
            // Open a connection to our database
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                // Our SQL query to fetch all saved games
                var query = "SELECT Id AS GameId, UserId, GameName, DateSaved, GameData FROM Games";

                // We'll store all the saved games we find here
                var savedGames = new List<SavedGame>();

                // Create a command to run our query
                using (var command = new SqlCommand(query, connection))
                {
                    // Run the query and get a reader for the results
                    using (var reader = command.ExecuteReader())
                    {
                        // Read each game row and build SavedGame objects
                        while (reader.Read())
                        {
                            savedGames.Add(new SavedGame
                            {
                                GameId = reader.GetInt32(reader.GetOrdinal("GameId")),
                                UserId = reader.IsDBNull(reader.GetOrdinal("UserId")) ? null : (int?)reader.GetInt32(reader.GetOrdinal("UserId")),
                                GameName = reader.IsDBNull(reader.GetOrdinal("GameName")) ? "Unnamed Game" : reader.GetString(reader.GetOrdinal("GameName")),
                                SaveDate = reader.GetDateTime(reader.GetOrdinal("DateSaved")),
                                GameData = reader.GetString(reader.GetOrdinal("GameData"))
                            });
                        }
                    }
                }

                // Return the "ShowSavedGames" view and pass it the list of saved games
                return View("ShowSavedGames", savedGames);
            }
        }
        catch (Exception ex)
        {
            // If something went wrong, log the error and show an error view
            Console.WriteLine($"Error loading saved games: {ex.Message}");
            return View("Error"); // Make sure there's an Error.cshtml to display
        }
    }

    ///-----------------------------------------------SHOW GAME END-----------------------------------------------------------------------///


    ///----------------------------------------------- LOAD GAME END-----------------------------------------------------------------------///

    /// <summary>
    /// Loads a previously saved game from the database using the provided gameId.
    /// If found, it deserializes the game data, restores the board state, and redirects to the Board view.
    /// If not found, it returns a NotFound result.
    /// </summary>
    [HttpPost]
    public IActionResult LoadGame(int gameId)
    {
        // Create a new connection to the database using the connection string
        using (var connection = new SqlConnection(connectionString))
        {
            // Open the database connection
            connection.Open();

            // Define the SQL query to select all columns from the Games table where Id matches @GameId
            var query = "SELECT * FROM Games WHERE Id = @GameId";

            // Create a new SQL command with the query and the open connection
            using (var command = new SqlCommand(query, connection))
            {
                // Add the parameter value for @GameId using the provided gameId variable
                command.Parameters.AddWithValue("@GameId", gameId);

                // Execute the command and obtain a reader for the returned rows
                using (var reader = command.ExecuteReader())
                {
                    // Check if we can read a row (which means a matching game was found)
                    if (reader.Read())
                    {
                        // Retrieve the "GameData" column from the current record
                        var gameData = reader.GetString(reader.GetOrdinal("GameData"));

                        // Deserialize the JSON stored in GameData back into a Board object
                        var board = JsonConvert.DeserializeObject<Board>(gameData);

                        // Save the board into the user's session or appropriate storage for continued play
                        SaveBoard(board);

                        // Redirect to the "Board" action to display the loaded game
                        return RedirectToAction("Board");
                    }
                }
            }
        }

        // If no record was found, return a 404 Not Found response
        return NotFound();
    }
    ///----------------------------------------------- LOAD GAME END-----------------------------------------------------------------------///
    


    // ---------------------------------------------- DELETE ACTION ----------------------------------------------------- //
    /// <summary>
    /// Deletes a saved game from the database based on the provided game ID,
    /// and then redirects back to the list of saved games.
    /// </summary>
    [HttpPost]
    public IActionResult DeleteGame(int gameId)
    {
        // Create a new database connection using the predefined connection string
        using (var connection = new SqlConnection(connectionString))
        {
            // Open the database connection
            connection.Open();

            // Define the SQL statement to delete a game with the specified Id
            var query = "DELETE FROM Games WHERE Id = @GameId";

            // Create a command to run the SQL statement, and associate it with the open connection
            using (var command = new SqlCommand(query, connection))
            {
                // Provide the actual gameId value for the @GameId parameter in the SQL query
                command.Parameters.AddWithValue("@GameId", gameId);

                // Execute the command to delete the record from the database
                command.ExecuteNonQuery();
            }
        }

        // After deletion is complete, go back to the page that shows all saved games
        return RedirectToAction("ShowSavedGames");
    }

    // ---------------------------------------------- DELETE ACTION END ----------------------------------------------------- //


    // ---------------------------------------------- SHOW SAVE GAME ACTION ----------------------------------------------------- //
    /// <summary>
    /// Displays all saved games with additional error handling.
    /// </summary>
    [HttpGet]
    public IActionResult ShowSavedGamesWithErrorHandling()
    {
        try
        {
            using (var connection = new SqlConnection(connectionString))
            {
                connection.Open();

                var query = "SELECT GameId, UserId, GameName, DateSaved, GameData FROM Games";
                var savedGames = new List<SavedGame>();

                using (var command = new SqlCommand(query, connection))
                {
                    using (var reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            savedGames.Add(new SavedGame
                            {
                                GameId = reader.GetInt32(reader.GetOrdinal("GameId")),
                                UserId = reader.IsDBNull(reader.GetOrdinal("UserId"))
                                         ? null : (int?)reader.GetInt32(reader.GetOrdinal("UserId")),
                                GameName = reader.GetString(reader.GetOrdinal("GameName")),
                                SaveDate = reader.GetDateTime(reader.GetOrdinal("DateSaved")),
                                GameData = reader.GetString(reader.GetOrdinal("GameData"))
                            });
                        }
                    }
                }

                return View("ShowSavedGames", savedGames); // Pass the data to the correct view
            }
        }
        catch (Exception ex)
        {
            // Log the exception and return an error view if needed
            Console.WriteLine($"Error fetching saved games: {ex.Message}");
            return View("Error"); // Replace with a proper error handling page
        }
    }
    // ---------------------------------------------- SHOW SAVE GAME ACTION END----------------------------------------------------- //

    /// <summary>
    /// Validates the connection string and database integrity.
    /// </summary>
    private void ValidateDatabaseConnection()
    {
        try
        {
            // Try connecting to the database
            using (var connection = new SqlConnection(connectionString))
            {
                // Open the connection and confirm it works
                connection.Open();
                Console.WriteLine("Database connection is valid.");
            }
        }
        catch (Exception ex)
        {
            // If there's an error, say so and throw an exception
            Console.WriteLine($"Database connection failed: {ex.Message}");
            throw new InvalidOperationException("Unable to connect to the database. Check connection settings.");
        }
    }




}
