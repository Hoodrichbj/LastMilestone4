﻿namespace CST_350_Minesweeper_Website.Models
{
    // This class represents a saved game with its details and data.
    public class SavedGame
    {
        public int GameId { get; set; }
        public int? UserId { get; set; } // Nullable if not tied to a specific user
        public string GameName { get; set; }
        public DateTime SaveDate { get; set; } // Timestamp of when the game was saved
        public string GameData { get; set; } // Serialized game state (e.g., JSON or binary)
    }
}
