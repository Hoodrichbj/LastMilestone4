﻿namespace CST_350_Minesweeper_Website.Models
{
    public class GameStateModel
    {
        public int GameId { get; set; } 
        public string GameData { get; set; }
        public DateTime DateSaved { get; set; }
    }
}
