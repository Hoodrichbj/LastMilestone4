﻿using CST_350_Minesweeper_Website.Interfaces;
using CST_350_Minesweeper_Website.Models;
using System.Data.SqlClient;

namespace CST_350_Minesweeper_Website.Services.DataAccess
{
    /// <summary>
    /// This class handles all database interactions for User and Saved Game management.
    /// </summary>
    public class UserDAO : IUserManager
    {
        // Define the connection string for MSSQL
        static string conn = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=UserProfile;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        /// <summary>
        /// Adds a new user to the database.
        /// </summary>
        public int AddUser(UserModel user)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                string query = "INSERT INTO UserProfile (Username, PasswordHash, FirstName, LastName, Sex, Age, Email)" +
                               "VALUES (@Username, @PasswordHash, @FirstName, @LastName, @Sex, @Age, @Email); SELECT SCOPE_IDENTITY();";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", user.Username);
                    command.Parameters.AddWithValue("@PasswordHash", user.PasswordHash);
                    command.Parameters.AddWithValue("@FirstName", user.FirstName);
                    command.Parameters.AddWithValue("@LastName", user.LastName);
                    command.Parameters.AddWithValue("@Sex", user.Sex);
                    command.Parameters.AddWithValue("@Age", user.Age);
                    command.Parameters.AddWithValue("@Email", user.Email);

                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }

        /// <summary>
        /// Validates user credentials by checking username and password against the database.
        /// </summary>
        public UserModel CheckCredentials(string username, string password)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                string query = "SELECT * FROM UserProfile WHERE Username = @Username AND PasswordHash = @Password";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", username);
                    command.Parameters.AddWithValue("@Password", password);

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return new UserModel
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                PasswordHash = reader.GetString(reader.GetOrdinal("PasswordHash")),
                                FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                                LastName = reader.GetString(reader.GetOrdinal("LastName")),
                                Age = reader.GetInt32(reader.GetOrdinal("Age")),
                                Sex = reader.GetString(reader.GetOrdinal("Sex")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                            };
                        }
                    }
                }
            }
            return null;
        }

        /// <summary>
        /// Deletes a user from the database by their ID.
        /// </summary>
        public void DeleteUser(UserModel user)
        {
            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();
                string query = "DELETE FROM UserProfile WHERE Id = @Id";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Id", user.Id);
                    command.ExecuteNonQuery();
                }
            }
        }

        /// <summary>
        /// Retrieves a list of all users from the database and returns them as a list of UserModel objects.
        /// </summary>
        public List<UserModel> GetAllUsers()
        {
            // Create a list to store the users we fetch from the database
            List<UserModel> users = new List<UserModel>();

            // Use a connection to the database with the given connection string
            using (SqlConnection connection = new SqlConnection(conn))
            {
                // Open the database connection
                connection.Open();

                // SQL statement to select all rows and columns from the UserProfile table
                string query = "SELECT * FROM UserProfile";

                // Create a command that will run our SQL query
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Execute the query and get a reader to read the returned rows
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // Loop through each returned row from the UserProfile table
                        while (reader.Read())
                        {
                            // Create a new UserModel and populate it with data from the current row
                            users.Add(new UserModel
                            {
                                Id = reader.GetInt32(reader.GetOrdinal("Id")),
                                Username = reader.GetString(reader.GetOrdinal("Username")),
                                PasswordHash = reader.GetString(reader.GetOrdinal("PasswordHash")),
                                FirstName = reader.GetString(reader.GetOrdinal("FirstName")),
                                LastName = reader.GetString(reader.GetOrdinal("LastName")),
                                Age = reader.GetInt32(reader.GetOrdinal("Age")),
                                Sex = reader.GetString(reader.GetOrdinal("Sex")),
                                Email = reader.GetString(reader.GetOrdinal("Email")),
                            });
                        }
                    }
                }
            }

            // Return the complete list of users we gathered
            return users;
        }

        ///-----------------------------------ADD A SAVE  GAME -------------------------------------/////
        /// <summary>
        /// Adds a new saved game record to the database and returns the newly created game's ID.
        /// </summary>
        public int AddSavedGame(SavedGame savedGame)
        {
            // Create a database connection using the connection string
            using (SqlConnection connection = new SqlConnection(conn))
            {
                // Open the database connection
                connection.Open();

                // Prepare an INSERT statement that adds a new record to SavedGames.
                // SELECT SCOPE_IDENTITY() returns the ID of the newly inserted row.
                string query = "INSERT INTO SavedGames (UserId, GameName, SaveDate, GameData) " +
                               "VALUES (@UserId, @GameName, @SaveDate, @GameData); SELECT SCOPE_IDENTITY();";

                // Create a SQL command to execute the query
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Assign parameter values to match the properties of the savedGame object
                    command.Parameters.AddWithValue("@UserId", savedGame.UserId ?? (object)DBNull.Value);
                    command.Parameters.AddWithValue("@GameName", savedGame.GameName);
                    command.Parameters.AddWithValue("@SaveDate", savedGame.SaveDate);
                    command.Parameters.AddWithValue("@GameData", savedGame.GameData);

                    // Execute the INSERT and get the newly generated ID
                    return Convert.ToInt32(command.ExecuteScalar());
                }
            }
        }
        ///-----------------------------------ADD A SAVE  GAME END -------------------------------------/////



        ///----------------------------------- LOAD SAVED GAMES -------------------------------------/////
        /// <summary>
        /// Loads a saved game by its ID.
        /// </summary>
        public SavedGame LoadSavedGame(int gameId)
        {
            // Connect to the database
            using (SqlConnection connection = new SqlConnection(conn))
            {
                // Open the connection so we can talk to the database
                connection.Open();

                // Our SQL to find the saved game by its ID
                string query = "SELECT * FROM SavedGames WHERE GameId = @GameId";

                // Set up the command to run the SQL
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Plug in the actual ID into the query
                    command.Parameters.AddWithValue("@GameId", gameId);

                    // Run the query and get back rows
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        // If we got a row back, fill a new SavedGame object with its data
                        if (reader.Read())
                        {
                            return new SavedGame
                            {
                                GameId = reader.GetInt32(reader.GetOrdinal("GameId")),
                                UserId = reader["UserId"] as int?,
                                GameName = reader.GetString(reader.GetOrdinal("GameName")),
                                SaveDate = reader.GetDateTime(reader.GetOrdinal("SaveDate")),
                                GameData = reader.GetString(reader.GetOrdinal("GameData")),
                            };
                        }
                    }
                }
            }

            // If no game was found, return null
            return null;
        }



        ///----------------------------------- LOAD SAVED GAMES END  -------------------------------------/////




        ///-----------------------------------DELTE A SAVED GAME -------------------------------------/////

        /// <summary>
        /// Deletes a saved game by its ID from the database.
        /// </summary>
        public void DeleteSavedGame(int gameId)
        {
            // Make a connection to the database
            using (SqlConnection connection = new SqlConnection(conn))
            {
                // Open the database connection
                connection.Open();

                // The SQL statement that deletes the game matching the provided ID
                string query = "DELETE FROM SavedGames WHERE GameId = @GameId";

                // Set up the command to run the DELETE query
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    // Substitute @GameId in the query with the actual gameId value
                    command.Parameters.AddWithValue("@GameId", gameId);

                    // Execute the DELETE statement to remove the game from the database
                    command.ExecuteNonQuery();
                }
            }
        }

        ///-----------------------------------DELTE A SAVED GAME END  -------------------------------------/////
        


        /// <summary>
        /// Retrieves all saved games, optionally filtered by user ID.
        /// </summary>
        public List<SavedGame> GetAllSavedGames(int? userId = null)
        {
            List<SavedGame> savedGames = new List<SavedGame>();

            using (SqlConnection connection = new SqlConnection(conn))
            {
                connection.Open();

                string query = "SELECT * FROM SavedGames";
                if (userId.HasValue)
                {
                    query += " WHERE UserId = @UserId";
                }

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    if (userId.HasValue)
                    {
                        command.Parameters.AddWithValue("@UserId", userId.Value);
                    }

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            savedGames.Add(new SavedGame
                            {
                                GameId = reader.GetInt32(reader.GetOrdinal("GameId")),
                                UserId = reader["UserId"] as int?,
                                GameName = reader.GetString(reader.GetOrdinal("GameName")),
                                SaveDate = reader.GetDateTime(reader.GetOrdinal("SaveDate")),
                                GameData = reader.GetString(reader.GetOrdinal("GameData")),
                            });
                        }
                    }
                }
            }

            return savedGames;
        }

        public UserModel GetUserById(int id)
        {
            throw new NotImplementedException();
        }

        public void UpdateUser(UserModel user)
        {
            throw new NotImplementedException();
        }

    }
}
