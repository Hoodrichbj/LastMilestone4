﻿namespace CST_350_Minesweeper_Website.Services.Business
{
    public class Board
    {
        // Square board
        public int Size { get; set; }
        // Array of cell objects
        public Cell[,] Grid { get; set; }
        public decimal Difficulty { get; set; }
        public int InitialBombCount { get; set; }

        /// <summary>
        /// Parameterized constructor
        /// </summary>
        /// <param name="s"></param>
        /// <param name="d"></param>
        public Board(int s, int d)
        {
            Difficulty = d;
            Size = s;
            Grid = new Cell[Size, Size];
            // Fill the grid with Cell objects
            for (int i = 0; i < Size; i++)
            {
                for (int j = 0; j < Size; j++)
                {
                    Grid[i, j] = new Cell(i, j);
                }
            }
        }

        // -------------------------------------------- GENERATE BOMBS METHOD -------------------------------------------- //
        /// <summary>
        /// Generates the bombs at random spots on the board based on difficulty
        /// </summary>
        /// <param name="startRow"></param>
        /// <param name="startCol"></param>
        public int GenerateBombs(int startRow, int startCol)
        {
            // Instantiate Random class
            Random rand = new Random();
            Cell startCell = Grid[startRow, startCol];
            // Calculate the total number of bombs necessary
            int bombCount = decimal.ToInt32(Convert.ToDecimal(Size) * Convert.ToDecimal(Size) * (Difficulty / 100));
            InitialBombCount = bombCount;
            // Repeats until all the bombs are placed
            while (bombCount > 0)
            {
                // Generate random numbers for row and column
                int row = rand.Next(0, Size);
                int col = rand.Next(0, Size);
                Cell randCell = Grid[row, col];

                // The second condition is here to prevent a loss right after the first cell is chosen
                if (randCell.IsLive != true && !randCell.Equals(startCell))
                {
                    randCell.IsLive = true;
                    bombCount--;
                }
            }
            // Calculate the number of live neighbors
            CalculateLiveNeighbors();
            // If the starting cell has any live neighbors, use recursion to try again
            if (startCell.LiveNeighbors > 0)
            {
                // Reset all the cells
                foreach (Cell cell in Grid)
                {
                    cell.IsLive = false;
                    cell.LiveNeighbors = 0;
                }
                // Generate the board again
                GenerateBombs(startRow, startCol);
            }
            // When it makes a valid board, return the initial bomb count
            return InitialBombCount;
        }
        // ----------------------------------------- END OF GENERATE BOMBS METHOD ----------------------------------------- //

        // ---------------------------------------------- UPDATE BOARD METHOD --------------------------------------------- //
        /// <summary>
        /// Updates the board with the new reveal/flag conditions
        /// </summary>
        /// <param name="revealedRow"></param>
        /// <param name="revealedCol"></param>
        /// <param name="flagCell"></param>
        /// <returns></returns>
        public (bool, int, int) UpdateBoard(int revealedRow, int revealedCol, bool flagCell, bool quickSweep)
        {
            int remainingCells = 0, flagCount = 0, bombCount = 0;
            // Object placeholder variable
            Cell selectedCell = Grid[revealedRow, revealedCol];
            if (quickSweep && selectedCell.IsRevealed && !flagCell) QuickSweep(revealedRow, revealedCol);
            // If the cell isn't flagged, flag it (if it isn't revealed) and if it is, unflag it
            else if (flagCell == true && !selectedCell.IsRevealed) selectedCell.IsFlagged = !selectedCell.IsFlagged;
            // If the live neighbors is 0, start the recursion process
            else if (Grid[revealedRow, revealedCol].LiveNeighbors == 0) FloodFill(revealedRow, revealedCol);
            // If the cell ins't flagged, reveal it
            else if (!selectedCell.IsFlagged) selectedCell.IsRevealed = true;

            // Scans each cell to get the count for flags, bombs, and remaining cells
            foreach (Cell cell in Grid)
            {
                if (cell.IsFlagged) flagCount++;
                if (cell.IsLive) bombCount++;
                if (!cell.IsRevealed) remainingCells++;
                if (cell.IsRevealed == true && cell.IsLive == true) return (true, -1, bombCount);
            }
            // Returns different things based on the condition of the board
            if (remainingCells - bombCount == 0) return (true, 0, 0);
            return (false, remainingCells, bombCount - flagCount);
        }
        // ------------------------------------------- END OF UPDATE BOARD METHOD ------------------------------------------ //

        // ----------------------------------------------- FLOOD FILL METHOD ----------------------------------------------- //
        /// <summary>
        /// Flood fill recursion method for empty cells
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void FloodFill(int row, int col)
        {
            // If statements staggered to prevent an out of bounds error
            if (row < 0 || row > Size - 1 || col < 0 || col > Size - 1) return;
            else if (Grid[row, col].IsFlagged == true || Grid[row, col].IsRevealed) return;
            else if (Grid[row, col].LiveNeighbors > 0)
            {
                // Reveals cells on the edges that have live neighbors
                Grid[row, col].IsRevealed = true;
                return;
            }

            // Reveals the cell
            Grid[row, col].IsRevealed = true;
            // Recursive in all 8 directions
            FloodFill(row - 1, col);
            FloodFill(row - 1, col + 1);
            FloodFill(row, col + 1);
            FloodFill(row + 1, col + 1);
            FloodFill(row + 1, col);
            FloodFill(row + 1, col - 1);
            FloodFill(row, col - 1);
            FloodFill(row - 1, col - 1);
        }
        // ------------------------------------------- END OF FLOOD FILL METHOD -------------------------------------------- //

        // ---------------------------------------- CALCULATE LIVE NEIGHBORS METHOD ---------------------------------------- //
        /// <summary>
        /// Determines the number of live cells in a 3x3 area around each cell
        /// </summary>
        /// <param name="currentCell"></param>
        public void CalculateLiveNeighbors()
        {
            // Nested loops to run for every cell in the grid
            for (var i = 0; i < Size; i++)
            {
                for (var j = 0; j < Size; j++)
                {
                    // Sets a variable equal to the current cell
                    var currentCell = Grid[i, j];
                    // Resets the count
                    int count = 0;
                    // If the cell is a bomb, skip this cell
                    if (currentCell.IsLive == true) continue;

                    // Nested loops that make the 3x3 grid around the cell
                    for (int r = -1; r <= 1; r++)
                    {
                        for (int c = -1; c <= 1; c++)
                        {
                            // Skips the current cell at (0,0 index)
                            if (r == 0 && c == 0) continue;

                            // Indexes of the row and column for the neighbor
                            int newRow = currentCell.RowNumber + r;
                            int newCol = currentCell.ColumnNumber + c;

                            // If the indexes are in bounds and the cell is live, increase the count
                            if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size && Grid[newRow, newCol].IsLive)
                            {
                                count++;
                            }
                        }
                    }
                    // Set the number of Neighbors for the sell to the count variable
                    currentCell.LiveNeighbors = count;
                }
            }
        }
        // ------------------------------------- END OF CALCULATE LIVE NEIGHBORS METHOD ------------------------------------- //

        // ----------------------------------------------- QUICKSWEEP METHOD ------------------------------------------------ //
        /// <summary>
        /// Method to quickly scan all the adjacent squares
        /// </summary>
        /// <param name="row"></param>
        /// <param name="col"></param>
        public void QuickSweep(int row, int col)
        {
            Cell currentCell = Grid[row, col];

            for (int r = -1; r <= 1; r++)
            {
                for (int c = -1; c <= 1; c++)
                {
                    // Skips the current cell at (0,0 index)
                    if (r == 0 && c == 0) continue;

                    int newRow = currentCell.RowNumber + r;
                    int newCol = currentCell.ColumnNumber + c;

                    // Reveal all the adjacent squares
                    if (newRow >= 0 && newRow < Size && newCol >= 0 && newCol < Size && !Grid[newRow, newCol].IsFlagged)
                    {
                        if (Grid[newRow, newCol].LiveNeighbors == 0) FloodFill(newRow, newCol);
                        Grid[newRow, newCol].IsRevealed = true;
                    }
                }
            }
        }
        // -------------------------------------------- END OF QUICKSWEEP METHOD --------------------------------------------- //
    }
}